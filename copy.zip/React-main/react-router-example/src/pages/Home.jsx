export default function Home() {
  return <div>Home 페이지 입니다.</div>;
}
